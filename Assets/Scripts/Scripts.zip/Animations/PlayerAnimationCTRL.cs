using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimationCTRL : MonoBehaviour
{
    public Animator anim;
    // Start is called before the first frame update
    public AnimatorStateInfo currAnimState;
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
